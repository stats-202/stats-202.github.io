setwd("/Users/tranlm/Google Drive/homework/hw2/data")

# Ch4 Q10
require(ISLR)
data(Weekly)
write.csv(Weekly, file='./Weekly.csv', row.names=FALSE)

# Ch5 Q5
data(Default)
write.csv(Default, file='./Default.csv', row.names=FALSE)

# Ch5 Q8
set.seed(1)
y <- rnorm(100)
x <- rnorm(100)
y <- x - 2 * x^2 + rnorm(100)
O <- data.frame(x, y)
write.csv(O, file='./ch5_ex8.csv', row.names=FALSE)

# Ch5 Q9
require(MASS)
data(Boston)
write.csv(Boston, file='./Boston.csv', row.names=FALSE)
